// controllers/giftBoxController.js
const GiftBox = require("../models/giftBox");
const GiftBoxOrderHistory = require("../models/giftBoxOrderHistory");
const VendorOrder = require("../models/vendorOrder");
const CartGiftBox = require("../models/cartGiftBox");

// 1. Create Gift Box After Payment
const createGiftBox = async (req, res) => {
  try {
    const {
      name,
      total_items,
      time_to_assemble,
      estimated_date_of_delivery,
      card_option,
      message,
      total_price,
      cart_source_id,
      items,
    } = req.body;

    const giftBox = await GiftBox.create({
      name,
      total_items,
      time_to_assemble,
      estimated_date_of_delivery,
      card_option,
      message,
      total_price,
      created_by: "user_created",
      cart_source_id: cart_source_id || null,
    });

    await GiftBoxOrderHistory.create({
      customer_id: req.user.id,
      gift_box_id: giftBox._id,
      status: "pending",
    });

    const vendorOrders = items.map((productId) => ({
      product_id: productId,
      customer_id: req.user.id,
      status: "pending",
    }));
    await VendorOrder.insertMany(vendorOrders);

    if (cart_source_id) {
      await CartGiftBox.findByIdAndUpdate(cart_source_id, {
        checked_out: true,
      });
    }

    res.status(201).json({ message: "Gift box created", giftBox });
  } catch (error) {
    console.error("Create Gift Box Error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

// 2. Get Gift Boxes for User
const getUserGiftBoxes = async (req, res) => {
  try {
    const history = await GiftBoxOrderHistory.find({
      customer_id: req.user.id,
    }).populate("gift_box_id");
    res.status(200).json(history);
  } catch (error) {
    console.error("Get Gift Boxes Error:", error);
    res.status(500).json({ message: "Server error" });
  }
};

module.exports = {
  createGiftBox,
  getUserGiftBoxes,
};
