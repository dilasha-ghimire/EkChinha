function UserProfile() {
  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h1>User Profile</h1>
      <p>Put your User Profile here.</p>
    </div>
  );
}

export default UserProfile;
