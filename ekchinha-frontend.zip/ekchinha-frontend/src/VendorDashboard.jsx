function VendorDashboard() {
  return (
    <div style={{ padding: "40px", textAlign: "center" }}>
      <h1>Vendor Dashboard</h1>
      <p>Put your Vendor Dashboard here.</p>
    </div>
  );
}

export default VendorDashboard;
